﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 学生管理系统
{
    public partial class Form1 : Form
    {
      
        public Form1()
        {
            InitializeComponent();
            BindData();
           
        } 

        private void BindData()
        {
            string connstr = "server=localhost;database=student;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connstr);
            conn.Open();

            string sqlstr = "select * from dbo.s1";
            SqlDataAdapter da = new SqlDataAdapter(sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];
            conn.Close();

        }


        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            show_sid.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            show_class.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            show_name.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            show_sex.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();

        }

        private void update_Click(object sender, EventArgs e)
        {
            string strcon = "server=localhost;database=student;Integrated Security=True";
            //1、新建通道
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = strcon;
            //2、准备新增sql命令
            string strcommand = "update dbo.s1 set student_id='" 
                +  show_sid.Text 
                + "',name='" 
                +  show_name.Text 
                + "',class_name='" 
                + show_class.Text 
                +"',sex='" 
                + show_sex.Text 
                + "' where id=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            //3、新建命令对象，并前告诉它走那条路，做什么事情
            SqlCommand cmd = new SqlCommand(strcommand, conn);
            //4、打开通道
            conn.Open();
            //5、执行sql语句
            int intres = -1;
            intres = cmd.ExecuteNonQuery();
            //6、关闭连接通道
            conn.Close();
            if (intres > 0)
            {
                MessageBox.Show("修改成功");
                show_sid.Text = "";
                show_class.Text = "";
                show_name.Text= "";
                show_sex.Text= "";
                BindData();
            }
            else
            {
              MessageBox.Show("修改失败");
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {

            string strcon = "server=localhost;database=student;Integrated Security=True";
            //1、新建通道
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = strcon;
            //2、准备新增sql命令
            string strcommand = " delete from dbo.s1 where id=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            SqlCommand cmd = new SqlCommand(strcommand, conn);
            //4、打开通道
            conn.Open();
            //5、执行sql语句
            int intres = -1;
            intres = cmd.ExecuteNonQuery();
            //6、关闭连接通道
            conn.Close();
            if (intres > 0)
            {
                MessageBox.Show("删除成功");
                show_sid.Text = "";
                show_class.Text = "";
                show_name.Text = "";
                show_sex.Text = "";
                BindData();
            }
            else
            {
                MessageBox.Show("删除失败");
            }

        }

        private void select_Click(object sender, EventArgs e)
        {
            string connstr = "server=localhost;database=student;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connstr);
            conn.Open();

            string sqlstr = "select * from dbo.s1 where 1 = 1";
            if (!student_id.Text.Equals(""))
            {
                sqlstr += " and student_id = " + "'"+student_id.Text+"'";
            }
            if (!name.Text.Equals(""))
            {
                sqlstr += " and name = " + "'" + name.Text + "'";
            }
            if (!class_name.Text.Equals(""))
            {
                sqlstr += " and class_name = " + "'" + class_name.Text + "'";
            }

            SqlDataAdapter da = new SqlDataAdapter(sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];
            conn.Close();
        }

        private void insert_Click(object sender, EventArgs e)
        {
             Form2 f = new Form2();
             f.Show();
             this.Hide();
    
        }

       
    }
}
