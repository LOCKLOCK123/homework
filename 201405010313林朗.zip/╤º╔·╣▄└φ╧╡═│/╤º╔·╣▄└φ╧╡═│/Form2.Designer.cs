﻿namespace 学生管理系统
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.add_id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.add_name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.add_class = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rb_boy = new System.Windows.Forms.RadioButton();
            this.rb_girl = new System.Windows.Forms.RadioButton();
            this.sure_insert = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(40, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "学号";
            // 
            // add_id
            // 
            this.add_id.Location = new System.Drawing.Point(117, 30);
            this.add_id.Name = "add_id";
            this.add_id.Size = new System.Drawing.Size(195, 28);
            this.add_id.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("楷体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(40, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "姓名";
            // 
            // add_name
            // 
            this.add_name.Location = new System.Drawing.Point(117, 93);
            this.add_name.Name = "add_name";
            this.add_name.Size = new System.Drawing.Size(195, 28);
            this.add_name.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(41, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "班级";
            // 
            // add_class
            // 
            this.add_class.Location = new System.Drawing.Point(117, 157);
            this.add_class.Name = "add_class";
            this.add_class.Size = new System.Drawing.Size(195, 28);
            this.add_class.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(44, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "性别";
            // 
            // rb_boy
            // 
            this.rb_boy.AutoSize = true;
            this.rb_boy.Checked = true;
            this.rb_boy.Location = new System.Drawing.Point(121, 245);
            this.rb_boy.Name = "rb_boy";
            this.rb_boy.Size = new System.Drawing.Size(52, 22);
            this.rb_boy.TabIndex = 7;
            this.rb_boy.TabStop = true;
            this.rb_boy.Text = "男";
            this.rb_boy.UseVisualStyleBackColor = true;
            // 
            // rb_girl
            // 
            this.rb_girl.AutoSize = true;
            this.rb_girl.Location = new System.Drawing.Point(260, 245);
            this.rb_girl.Name = "rb_girl";
            this.rb_girl.Size = new System.Drawing.Size(52, 22);
            this.rb_girl.TabIndex = 8;
            this.rb_girl.Text = "女";
            this.rb_girl.UseVisualStyleBackColor = true;
            // 
            // sure_insert
            // 
            this.sure_insert.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.sure_insert.Location = new System.Drawing.Point(47, 310);
            this.sure_insert.Name = "sure_insert";
            this.sure_insert.Size = new System.Drawing.Size(122, 47);
            this.sure_insert.TabIndex = 9;
            this.sure_insert.Text = "确认添加";
            this.sure_insert.UseVisualStyleBackColor = true;
            this.sure_insert.Click += new System.EventHandler(this.sure_insert_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(247, 311);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 46);
            this.button1.TabIndex = 10;
            this.button1.Text = "取消";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 429);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.sure_insert);
            this.Controls.Add(this.rb_girl);
            this.Controls.Add(this.rb_boy);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.add_class);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.add_name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.add_id);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "Form2";
            this.Text = "学生添加界面";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox add_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox add_name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox add_class;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rb_boy;
        private System.Windows.Forms.RadioButton rb_girl;
        private System.Windows.Forms.Button sure_insert;
        private System.Windows.Forms.Button button1;
    }
}