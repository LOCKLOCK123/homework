﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 学生管理系统
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void sure_insert_Click(object sender, EventArgs e)
        {
            string sid = add_id.Text;
            string name = add_name.Text;
            string sex = " ";
            string class_name = add_class.Text;
            if (rb_boy.Checked) {
                sex = "男";
            }
            else if (rb_girl.Checked) {
                sex = "女";
            }
            if (sid.Equals(""))
            {
                MessageBox.Show("学号不可以为空");
                return;
            }
            else if (name.Equals(""))
            {
                MessageBox.Show("姓名不可为空");
                return;
            }
            else if (class_name.Equals("")) 
            {
                MessageBox.Show("班级不可为空");
                return;
            }
            string connstr = "server=localhost;database=student;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connstr);
            conn.Open();
            string sqlstr = "select * from dbo.s1 where student_id='" + sid + "'";
            SqlCommand cmd = new SqlCommand(sqlstr, conn);
		    SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                MessageBox.Show("该学号已存在");
                reader.Close();
                conn.Close();
                return;
            }
            else {
                 reader.Close();
                 sqlstr = "insert into dbo.s1 values('"+sid+"','"+name+"','"+class_name+"','"+sex+"')";
                 SqlCommand cmd1 = new SqlCommand(sqlstr, conn);
                 cmd1 = new SqlCommand(sqlstr, conn);
                 cmd1.ExecuteNonQuery();
                 conn.Close();
                 MessageBox.Show("添加成功");
                 Form1 f = new Form1();
                 f.Show();
                 this.Hide();
              }
         
           

         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();

        }

      
    }
}
