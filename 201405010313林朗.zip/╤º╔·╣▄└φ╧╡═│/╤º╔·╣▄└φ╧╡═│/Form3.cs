﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string name = tb_name.Text;
            string pwd = tb_paw.Text;
            if (name == null || name.Equals("")) {
                MessageBox.Show("用户名不能为空");
                return;
            }
            else if (pwd == null || pwd.Equals("")) {
                MessageBox.Show("密码不能为空");
                return;
            }
            if (pwd.Equals("123456") && name.Equals("admin"))
            {
                MessageBox.Show("登陆成功");
                Form1 f = new Form1();
                f.Show();
                this.Hide();

            }
            else {
                MessageBox.Show("登录失败");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tb_name.Text = "";
            tb_paw.Text = "";
        }

     
    }
}
